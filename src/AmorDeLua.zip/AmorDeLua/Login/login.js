document.addEventListener("DOMContentLoaded", () => {

    let botaoDeLogar = document.getElementById('loginButton');
    botaoDeLogar.addEventListener('click', async function (event) {
        event.preventDefault();

        try {
            let email = document.getElementById('email').value;
            let senha = document.getElementById('senha').value;

            const response = await fetch(`http://localhost:3302/usuario/emse/${email}/${senha}`, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json'
                }
            });

            const result = await response.json();

            if (response.status === 200) {
                localStorage.setItem('id', result[0].id);
                location.href = "../MeusPets/index.html";
            } else if (response.status === 400) {
                alert(result.message);
            }
        } catch (error) {
            console.log(error)
        }
    });
});
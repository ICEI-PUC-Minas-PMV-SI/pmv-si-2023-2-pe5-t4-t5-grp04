document.addEventListener("DOMContentLoaded", () => {


    async function carregarDados() {
        try {
            const cardAnimal = document.getElementById('cards');
            const response = await fetch(`http://localhost:3302/pet`, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json'
                }
            });
            const result = await response.json();
            if (response.status === 400) {
                cardAnimal.innerHTML = `
                    <h2>${result.message}</h2>
                `;
            } else if (response.status === 200) {
                cardAnimal.innerHTML = "";
                result.forEach((pet,index) => {
                    if(index < 4){
                        let bufferData = pet.img.data;
                        let uint8Array = new Uint8Array(bufferData);
                        let textData = new TextDecoder('utf-8').decode(uint8Array);
                        cardAnimal.innerHTML += `
                        <main>
                            <img src="${textData}" alt="cachoAdoção">
                            <p>
                                Nome: ${pet.nome}
                            </p>
                            <p>
                                Porte: ${pet.porte}
                            </p>
                            <p>
                                Raça: ${pet.raca}
                            </p>
                            <p>
                                Data do Resgate: ${pet.data}
                            </p>
                            <p>
                                Telefone: ${pet.telefone}
                            </p>
                        </main>
                        `;
                    }
                });
            }
        } catch (error) {
            console.log(error)
        }
    }
    carregarDados();
});
document.addEventListener("DOMContentLoaded", () => {

    const frmUsuario = document.getElementById('registerForm');
    frmUsuario.addEventListener('submit', async function (event) {
        try{
            event.preventDefault();
            const usuarios = {
                nome: document.getElementById('nome').value,
                telefone: document.getElementById('telefone').value,
                email: document.getElementById('email').value,
                senha: document.getElementById('senha').value
            }

            const response = await fetch('http://localhost:3302/usuario/addUsuario',{
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(usuarios)
            });

            const result = await response.json();
            console.log(result);

            if(response.status === 200){
                location.href = "../Login/index.html";
            }
            else if(response.status === 409){
                alert(result.message);
            }
            
        }catch(error){
            console.log(error)
        }
    });
});
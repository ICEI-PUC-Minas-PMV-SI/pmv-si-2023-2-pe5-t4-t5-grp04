document.addEventListener("DOMContentLoaded", () => {
    if(localStorage.getItem('id') === null){
        location.href = "../Login/index.html";
    }

    const frmAnimal = document.getElementById("frmAnimal");
    frmAnimal.addEventListener('submit', async function (event) {
        try {
            event.preventDefault();

            const pet = {
                nome: document.getElementById('nome').value,
                raca: document.getElementById('raca').value,
                porte: document.getElementById('porte').value,
                telefone: document.getElementById('telefone').value,
                data: document.getElementById('data').value,
                img: document.getElementById('img').value,
                usuario: localStorage.getItem('id')
            }
            const response = await fetch(`http://localhost:3302/pet/addPet`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(pet)
            });

            if (response.status === 200) {
                alert('Pet adicionado');
            }
            document.getElementById('nome').value = "";
            document.getElementById('raca').value = "";
            document.getElementById('porte').value = "";
            document.getElementById('telefone').value = "";
            document.getElementById('data').value = "";
            document.getElementById('img').value = "";

        } catch (error) {
            console.log(error)
        }
    });
});
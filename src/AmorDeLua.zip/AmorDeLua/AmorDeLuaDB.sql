drop database AmorDeLua;
create database AmorDeLua;
use AmorDeLua;

create table usuario(
id int unsigned not null auto_increment primary key,
nome varchar(40) not null,
telefone varchar(14) not null, 
email varchar(60) not null, 
senha varchar(25) not null
)engine=innodb;

select * from usuario;

create table pet(
id int unsigned not null auto_increment primary key,
nome varchar(40)not null, 
raca varchar(40) not null, 
porte varchar(15)not null, 
telefone varchar(14)not null, 
data varchar(10)not null, 
img blob not null,
usuario_fk int unsigned not null,
foreign key (usuario_fk) references usuario(id)
)engine=innodb;

select * from pet;
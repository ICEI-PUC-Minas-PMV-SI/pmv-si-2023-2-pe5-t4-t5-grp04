document.addEventListener("DOMContentLoaded", () => {
    if(localStorage.getItem('id') === null){
        location.href = "../Login/index.html";
    }

    const params = new URLSearchParams(window.location.search);
    const atu = document.getElementById("aa");
    atu.addEventListener("click", async function (event) {
        event.preventDefault();
        console.log("aaa");
        try {
            event.preventDefault();
            const pet = {
                img: document.getElementById("imgU").value,
                nome: document.getElementById("nomeU").value,
                porte: document.getElementById("porteU").value,
                raca: document.getElementById("racaU").value,
                data: document.getElementById("dataU").value,
                telefone: document.getElementById("telefoneU").value,
                id: params.get('id')
            }
    
            const response = await fetch('http://localhost:3302/pet/atuPet', {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(pet)
            });

            const result = await response.json();
            
            if(response.status === 400){
                alert('Algo deu errado!!');
            }else if(response.status === 200){
                alert('Pet atualizado!!');
                location.href = "../MeusPets/index.html";
            }
        } catch (error) {
            console.log(error)
        }
    })

});




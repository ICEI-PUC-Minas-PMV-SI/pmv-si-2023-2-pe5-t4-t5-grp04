const express = require('express');
const pet = require('./routers/pet.js');
const usuario = require('./routers/usuario.js');
const cors = require('cors');
const app = express();
app.use(express.json());
app.use(cors());
const PORT = 3302;

app.use('/pet', pet);
app.use('/usuario', usuario);

app.listen(PORT, () => {
    console.log(`Executando a aplicação na porta ${PORT}`);
});
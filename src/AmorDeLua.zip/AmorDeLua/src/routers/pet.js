const { Router } = require('express');
const querys = require('../querys');

const router = Router();

router.get('/', async (req,res) =>{
    try{
        const query = await querys .getAllPets();
        return res.status(200).json(query);
    }catch(Ex){
        console.log(Ex);
    }
})

router.get('/id/:id', async (req,res) =>{
    try{
        const {id} = req.params;
        const query = await querys.getPetById(id);
        if(query.length === 0){
            return res.status(400).json({message: 'pet not found'});
        }
        return res.status(200).json(query);
    }catch(Ex){
        console.log(Ex);
    }
});

router.get('/usuario/:usuario', async (req,res) =>{
    try {
        const {usuario} = req.params;
        const query = await querys.getPetByUser(usuario);
        if(query.length === 0){
            return res.status(400).json({message: 'pet not found'});
        }
        return res.status(200).json(query);
    } catch (error) {
        console.log(error)
    }
})

router.post('/addPet', async (req,res)=>{
    try{
        const {nome, raca, porte, telefone, data, img, usuario} = req.body;
        const query = await querys.createPet(nome, raca, porte, telefone, data, img, usuario);
        return res.status(200).json(query);
    }catch(Ex){
        console.log(Ex);
    }
});

router.put('/atuPet', async (req,res)=>{
    try{
        const {id, nome, raca, porte, telefone, data, img} = req.body;
        const query = await querys.updatePet(id, nome, raca, porte, telefone, data, img);
        if(query === null){
            return res.status(400).json({message: 'pet not found'});
        }
        return res.status(200).json({message: 'pet updated successfuly'});
    }catch(Ex){
        console.log(Ex);
    }
});

router.delete('/delPet', async (req,res) =>{
    try{
        const {id} = req.body;
        const query = await querys.deletePet(id);
        if(query === null){
            return res.status(400).json({message: 'pet not found'});
        }
        return res.status(200).json({message: 'pet deleted successfuly'});
    }catch(Ex){
        console.log(Ex);
    }
});

module.exports = router;
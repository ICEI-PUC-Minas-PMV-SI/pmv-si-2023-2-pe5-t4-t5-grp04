const {Router} = require('express');
const querys = require('../querys');

const router = Router();

router.get('/', async (req,res) => {
    try {
        const query = await querys.getAllUsuario();
        return res.status(200).json(query);
    } catch (error) {
        console.log(error)
    }
});

router.get('/id/:id', async (req,res)=>{
    try {
        const {id} = req.params;
        const query = await querys.getUsuarioById(id);
        if(query.length === 0){
            return res.status(400).json({message: 'usuario not found'});
        }
        return res.status(200).json(query);
    } catch (error) {
        console.log(error)
    }
});

router.get('/emse/:email/:senha', async (req,res)=>{
    try {
        const {email, senha} = req.params;
        const query = await querys.getUsuarioByEmSe(email,senha);
        if(query.length === 0){
            return res.status(400).json({message: 'usuario not found'});
        }
        return res.status(200).json(query);
    } catch (error) {
        console.log(error)
    }
});

router.get('/email/:email', async (req,res) =>{
    try {
        const {email} = req.params;
        const query = await querys.getUsuarioByEmail(email);
        if(query.length === 0){
            return res.status(400).json({message: 'usuario not found'});
        }
        return res.status(200).json(query);
    } catch (error) {
        console.log(error)
    }
})

router.post('/addUsuario', async (req,res)=>{
    try {
        const {nome,telefone, email, senha} = req.body;
        const query = await querys.createUsuario(nome,telefone, email, senha);
        if(query === null){
            return res.status(409).json({ message: 'Usuário já existente' });
        }
        return res.status(200).json(query);
    } catch (error) {
        console.log(error)
    }
});

module.exports = router







// try {
        
// } catch (error) {
//     console.log(error)
// }
const connection = require('./connection');

const getAllPets = async () =>{
    try{
        const [query] = await connection.execute(`SELECT * FROM AmorDeLua.pet`);
        return query;
    }catch(Ex){
        console.log(Ex);
    }
}

const getPetById = async (id) => {
    try{
        const [query] = await connection.execute(`SELECT * FROM AmorDeLua.pet WHERE id = ${id}`);
        return query;
    }catch(Ex){
        console.log(Ex);
    }
}

const getPetByUser = async (usuario) => {
    try {
        const [query] = await connection.execute(`SELECT * FROM AmorDeLua.pet WHERE usuario_fk = ${usuario}`);
        return query;
    } catch (error) {
        console.log(error)
    }
}

const createPet = async (nome, raca, porte, telefone, data, img, usuario) => {
    try {
        const [query] = await connection.execute(`INSERT INTO AmorDeLua.pet
        VALUES(NULL,"${nome}","${raca}","${porte}","${telefone}","${data}","${img}","${usuario}")`);
        return query;
    } catch (error) {
        console.log(error);
    }
}

const updatePet = async (id, nome, raca, porte, telefone, data, img) => {
    try {
        const item = await getPetById(id)
        if(item.length === 0){
            return null;
        }
        const [query] = await connection.execute(`UPDATE AmorDeLua.pet SET 
        nome = "${nome}", raca = "${raca}", porte = "${porte}",
         telefone = "${telefone}", data = "${data}", img = "${img}"
         WHERE id = ${id}`);
         return query;
    } catch (error) {
        console.log(error);
    }
}

const deletePet = async (id) =>{
    try {
        const item  = await getPetById(id);
        if(item.length === 0){
            return null;
        }
        const [query] = await connection.execute(`DELETE FROM AmorDeLua.pet WHERE id = ${id}`);
        return query;
    } catch (error) {
        console.log(error);
    }
}

const getAllUsuario = async ()=>{
    try {
        const [query] = await connection.execute(`SELECT * FROM AmorDeLua.usuario`);
        return query;
    } catch (error) {
        console.log(error)
    }
}

const getUsuarioById = async (id) => {
    try {
        const [query] = await connection.execute(`SELECT * FROM AmorDeLua.usuario
        WHERE id = ${id}`);
        return query;
    } catch (error) {
        console.log(error)
    }
}

const getUsuarioByEmSe = async (email,senha) =>{
    try {
        const [query] = await connection.execute(`SELECT * FROM AmorDeLua.usuario
        WHERE email = "${email}" AND senha = "${senha}"`);
        return query;
    } catch (error) {
        console.log(error)
    }
}

const getUsuarioByEmail = async (email) =>{
    try {
        const [query] = await connection.execute(`SELECT * FROM AmorDeLua.usuario
        WHERE email = "${email}"`);
        return query;
    } catch (error) {
        console.log(error)
    }
}

const createUsuario = async (nome,telefone, email, senha) =>{
    try {
        const item = await getUsuarioByEmail(email);
        if(item.length === 0){
            const [query] = await connection.execute(`INSERT INTO AmorDeLua.usuario 
            VALUES(NULL,"${nome}","${telefone}","${email}","${senha}")`);
            return query;
        }
        return null;
    } catch (error) {
        console.log(error);
    }
}

module.exports = {getAllPets, getPetById, getPetByUser, createPet, updatePet, deletePet, getAllUsuario, getUsuarioById, getUsuarioByEmSe, getUsuarioByEmail, createUsuario}